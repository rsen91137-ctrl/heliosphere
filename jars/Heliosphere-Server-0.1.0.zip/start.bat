@echo off
java -Xms2G -Xmx6G -jar fabric-server-launch.jar nogui
pause
